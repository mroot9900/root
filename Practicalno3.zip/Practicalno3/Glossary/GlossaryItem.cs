namespace Glossary
{
    public class GlossaryItem
    {
        public int Id { get; set; }

        public string Term { get; set; }

        public string Definition { get; set; }
    }
}