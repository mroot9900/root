using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace Glossary.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GlossaryController : ControllerBase
    {
        private static List<GlossaryItem> glossary = new List<GlossaryItem>()
        {
            new GlossaryItem { Term = "HTML", Definition = "Hypertext Markup Language" },
            new GlossaryItem { Term = "MVC", Definition = "Model View Controller" },
            new GlossaryItem { Term = "OpenID", Definition = "An open standard for authentication" }
        };

        [HttpPost]
        public IActionResult Post(GlossaryItem item)
        {
            glossary.Add(item);
            return Ok(item);
        }

        [HttpPut]
        public IActionResult Put(GlossaryItem item)
        {
            var existing = glossary.FirstOrDefault(x => x.Term.ToLower() == item.Term.ToLower());

            if (existing == null)
                return BadRequest("Cannot update a non-existing term");

            existing.Definition = item.Definition;

            return Ok(existing);
        }

        [HttpDelete("{term}")]
        public IActionResult Delete(string term)
        {
            var item = glossary.FirstOrDefault(x => x.Term.ToLower() == term.ToLower());

            if (item == null)
                return BadRequest("Cannot delete a non-existing term");

            glossary.Remove(item);

            return Ok("Term deleted successfully");
        }

        [HttpGet]
        public IEnumerable<GlossaryItem> GetAll()
        {
            return glossary;
        }

        [HttpGet("{term}")]
        public ActionResult<GlossaryItem> Get(string term)
        {
            var item = glossary.FirstOrDefault(x => x.Term.ToLower() == term.ToLower());

            if (item == null)
                return NotFound();

            return item;
        }
    }
}